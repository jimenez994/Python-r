from __future__ import unicode_literals

from django.apps import AppConfig


class DojoNinjasAppConfig(AppConfig):
    name = 'dojo_ninjas_app'
