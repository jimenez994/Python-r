from __future__ import unicode_literals

from django.apps import AppConfig


class SureysAppConfig(AppConfig):
    name = 'sureys_app'
